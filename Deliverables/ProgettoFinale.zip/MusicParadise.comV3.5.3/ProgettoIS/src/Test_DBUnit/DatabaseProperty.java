package Test_DBUnit;

public class DatabaseProperty {
	public static String DATABASE_DRIVER = "com.mysql.jdbc.Driver";
	public static String DATABASE_URL = "jdbc:mysql://127.0.0.1:3306/dbtest";
	public static String DATABASE_USERNAME = "root";
	public static String DATABASE_PASSWORD = "antonio@";
}
